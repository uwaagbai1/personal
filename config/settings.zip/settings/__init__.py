from .base import *

if env("PERSONAl") == 'development':
   from .production import *
else:
   from .development import *